package com.example.parkingapp;

import android.app.Application;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
/*
authentication ->uid
        user->uid
        feedback->owner/uid->user/uid  feedback
        booking->user/uid->push1
                           push2
        parking->owner/uid->push1
                            push2
*/

public class SingleTask extends Application {
    private FirebaseAuth mAuth;
    private FirebaseDatabase database;
    private GoogleSignInClient mGoogleSignInClient;
    private StorageReference mStorageRef;

    @Override
    public void onCreate() {
        super.onCreate();
        mAuth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        mStorageRef = FirebaseStorage.getInstance().getReference();
        GoogleSignInOptions gso = new GoogleSignInOptions.
                Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
    }

    public GoogleSignInClient getmGoogleSignInClient() {
        return mGoogleSignInClient;
    }

    public StorageReference getDocumentStorageIdProof() {
        return mStorageRef.child("idproofs/");
    }

    public DatabaseReference getUserDatabaseReference() {
        return database.getReference("users");
    }

    public DatabaseReference getProfileDatabaseReference() {
        return database.getReference("profile");
    }

    public DatabaseReference getFeedbackDatabaseReference() {
        return database.getReference("feedbacks");
    }

    public DatabaseReference getBookingDatabaseReference() {
        return database.getReference("bookings");
    }

    public DatabaseReference getParkingDatabaseReference() {
        return database.getReference("parkings");
    }

    public FirebaseAuth getFirebaseAuth() {
        return mAuth;
    }
}
