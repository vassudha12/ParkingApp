package com.example.parkingapp.model;

public class Profile {
    private String uid;
    private String email;
    private String name;
    private String mobile;
    private String address;
    private String chargeperhour;
    private String idproofurl;
    private String vehiclenumber;

    public String getVehiclenumber() {
        return vehiclenumber;
    }

    public void setVehiclenumber(String vehiclenumber) {
        this.vehiclenumber = vehiclenumber;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getChargeperhour() {
        return chargeperhour;
    }

    public void setChargeperhour(String chargeperhour) {
        this.chargeperhour = chargeperhour;
    }

    public String getIdproofurl() {
        return idproofurl;
    }

    public void setIdproofurl(String idproofurl) {
        this.idproofurl = idproofurl;
    }
}
