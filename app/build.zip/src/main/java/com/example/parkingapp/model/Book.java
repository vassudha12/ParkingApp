package com.example.parkingapp.model;

public class Book {
    private String date;
    private String time;
    private String owneruid;
    private String useruid;


}
