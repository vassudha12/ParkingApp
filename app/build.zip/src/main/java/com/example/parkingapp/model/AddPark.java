package com.example.parkingapp.model;

public class AddPark {

}
