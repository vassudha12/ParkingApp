package com.example.parkingapp.ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.daimajia.slider.library.Animations.DescriptionAnimation;
import com.daimajia.slider.library.SliderLayout;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.TextSliderView;
import com.daimajia.slider.library.Tricks.ViewPagerEx;
import com.example.parkingapp.HomePage;
import com.example.parkingapp.LoginActivity;
import com.example.parkingapp.R;
import com.example.parkingapp.SingleTask;
import com.example.parkingapp.adapter.ModuleAdapter;
import com.example.parkingapp.model.Module;
import com.facebook.login.Login;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class HomeFragment extends Fragment implements BaseSliderView.OnSliderClickListener, ViewPagerEx.OnPageChangeListener {
    private RecyclerView moduleRecyclerView;
    private List<Module> moduleList;
    private SliderLayout sliderLayout;
    private HashMap<String, Integer> Hash_file_maps;
    private Button logoutbutton;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //initialize all views
        initViews(view);
        //setlayout in recyclerview either grid or list
        moduleRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 2));
        //call your method where module list is define
        myModules();
        //give modules list to the custom moduleadapter class
        ModuleAdapter moduleAdapter = new ModuleAdapter(moduleList);
        //call custom method from moduleadater class
        moduleAdapter.setOnMyModuleClickListener(new ModuleAdapter.MyModuleClickListener() {
            @Override
            public void onModuleClick(View view, int position) {
                NavController navController = Navigation.findNavController(view);
                //get Module object from module list
                Module module = moduleList.get(position);
                if (module.getName().equalsIgnoreCase(getResources().getString(R.string.menu_book_parking))) {
                    //go to book parking page
                    navController.navigate(R.id.action_nav_home_to_nav_book_parking);
                    Toast.makeText(getActivity(), "Booking", Toast.LENGTH_SHORT).show();
                } else if (module.getName().equalsIgnoreCase(getResources().getString(R.string.menu_profile))) {
                    //go to profile page
                    navController.navigate(R.id.action_nav_home_to_nav_profile);
                    Toast.makeText(getActivity(), "Profile", Toast.LENGTH_SHORT).show();
                } else if (module.getName().equalsIgnoreCase(getResources().getString(R.string.menu_parking_history))) {
                    //go to parking history page
                    Toast.makeText(getActivity(), "Parking", Toast.LENGTH_SHORT).show();
                    navController.navigate(R.id.action_nav_home_to_nav_parking_history);
                } else if (module.getName().equalsIgnoreCase(getResources().getString(R.string.menu_add_parking))) {
                    //go to add parking page
                    navController.navigate(R.id.action_nav_home_to_nav_add_parking);
                    Toast.makeText(getActivity(), "Add Parking", Toast.LENGTH_SHORT).show();
                }

            }
        });
        //give module adapter object to recyclerview
        moduleRecyclerView.setAdapter(moduleAdapter);
        //logout code here
        logoutbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logout();
            }
        });
    }


    private void logout() {
        ((SingleTask) getActivity().getApplication()).getmGoogleSignInClient().signOut().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    ((SingleTask) getActivity().getApplication()).getFirebaseAuth().signOut();
                    startActivity(new Intent(getActivity(), LoginActivity.class));
                    getActivity().finish();

                }
            }
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        sliderLayout.stopAutoCycle();
    }

    @Override
    public void onStart() {
        super.onStart();
        sliderLayout.startAutoCycle();
    }

    private void myModules() {
        //create first module and property like name and image
        Module m1 = new Module(getResources().getString(R.string.menu_book_parking), R.drawable.booking);
        //create second module and property like name and image
        Module m2 = new Module(getResources().getString(R.string.menu_profile), R.drawable.profile);
        //create third module and property like name and image
        Module m3 = new Module(getResources().getString(R.string.menu_add_parking), R.drawable.add_parking);
        //create fourth module and property like name and image
        Module m4 = new Module(getResources().getString(R.string.menu_parking_history), R.drawable.parking_history);

        //add all module in list
        moduleList = new ArrayList<>();
        moduleList.add(m1);
        moduleList.add(m2);
        moduleList.add(m3);
        moduleList.add(m4);

    }


    private void initViews(View view) {
        moduleRecyclerView = view.findViewById(R.id.mymodulerecycler);
        sliderLayout = view.findViewById(R.id.slider);
        Hash_file_maps = new HashMap();
        logoutbutton = view.findViewById(R.id.logoutbutton);
        mySliderImages();

    }

    private void mySliderImages() {
        Hash_file_maps.put("Always check your area around.", R.drawable.park1);
        Hash_file_maps.put("There must not be litter on the ground.", R.drawable.park2);
        Hash_file_maps.put("Keep Parking clean to make it disease free.", R.drawable.park3);
        Hash_file_maps.put("Come, join and pledge together to park.", R.drawable.park4);
        Hash_file_maps.put("always follow the lane.", R.drawable.park5);

        for (String name : Hash_file_maps.keySet()) {

            TextSliderView textSliderView = new TextSliderView(getActivity());
            textSliderView
                    .description(name)
                    .image(Hash_file_maps.get(name))
                    .setScaleType(BaseSliderView.ScaleType.Fit)
                    .setOnSliderClickListener(this);
            textSliderView.bundle(new Bundle());
            textSliderView.getBundle()
                    .putString("extra", name);
            sliderLayout.addSlider(textSliderView);
        }

        sliderLayout.setPresetTransformer(SliderLayout.Transformer.Accordion);
        sliderLayout.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);
        sliderLayout.setCustomAnimation(new DescriptionAnimation());
        sliderLayout.setDuration(3000);
        sliderLayout.addOnPageChangeListener(this);

    }

    @Override
    public void onSliderClick(BaseSliderView slider) {

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}
